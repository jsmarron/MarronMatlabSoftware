function pauseSM 
% PAUSESM, Pause
%   Steve Marron's matlab function
%
%     Prompts for "hit any key", and then pauses

%    Copyright (c) J. S. Marron 1998, 2001


disp('    Pausing, Hit Any Key to Continue') ;
pause ;

